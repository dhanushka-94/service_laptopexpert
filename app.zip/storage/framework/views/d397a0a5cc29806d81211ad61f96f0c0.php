<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                Job: <?php echo e($job->job_id); ?>

            </h2>
            <div class="flex space-x-2">
                <a href="<?php echo e(route('jobs.edit', $job)); ?>" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-md text-sm">Edit Job</a>
                <a href="<?php echo e(route('jobs.print', $job)); ?>" class="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-md text-sm" target="_blank">Print Receipt</a>
                <a href="<?php echo e(route('jobs.pdf', $job)); ?>" class="bg-purple-500 hover:bg-purple-600 text-white px-4 py-2 rounded-md text-sm" target="_blank">Generate PDF</a>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <!-- Job Summary -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                <div class="p-6 bg-white border-b border-gray-200">
                    <div class="flex justify-between mb-4">
                        <div>
                            <h3 class="text-lg font-medium text-gray-900">Job Information</h3>
                            <p class="text-sm text-gray-500">Created on <?php echo e($job->created_at->format('M d, Y h:i A')); ?></p>
                        </div>
                        
                        <div>
                            <?php
                                $statusClass = [
                                    'Pending' => 'bg-yellow-100 text-yellow-800 border-yellow-200',
                                    'In Progress' => 'bg-blue-100 text-blue-800 border-blue-200',
                                    'Awaiting Parts' => 'bg-purple-100 text-purple-800 border-purple-200',
                                    'Repaired' => 'bg-green-100 text-green-800 border-green-200',
                                    'Delivered' => 'bg-gray-100 text-gray-800 border-gray-200',
                                    'Canceled' => 'bg-red-100 text-red-800 border-red-200',
                                ][$job->status] ?? 'bg-gray-100 text-gray-800 border-gray-200';
                            ?>
                            
                            <span class="px-3 py-1 border rounded-full text-sm font-medium <?php echo e($statusClass); ?>">
                                <?php echo e($job->status); ?>

                            </span>
                            
                            <!-- Update Status Form -->
                            <form action="<?php echo e(route('jobs.update-status', $job)); ?>" method="POST" class="mt-2">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="flex">
                                    <select name="status" class="rounded-l-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50 text-sm">
                                        <?php $__currentLoopData = ['Pending', 'In Progress', 'Awaiting Parts', 'Repaired', 'Delivered', 'Canceled']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($status); ?>" <?php echo e($job->status == $status ? 'selected' : ''); ?>><?php echo e($status); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <button type="submit" class="bg-gray-800 text-white rounded-r-md px-3 py-0 text-sm">Update</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <!-- Customer Info -->
                        <div>
                            <div class="mb-4">
                                <h4 class="text-sm font-medium text-gray-500">Customer</h4>
                                <p class="text-base">
                                    <a href="<?php echo e(route('customers.show', $job->customer)); ?>" class="text-blue-600 hover:text-blue-900">
                                        <?php echo e($job->customer->name); ?>

                                    </a>
                                </p>
                                <?php if($job->customer->phone): ?>
                                    <p class="text-sm text-gray-500">Phone: <?php echo e($job->customer->phone); ?></p>
                                <?php endif; ?>
                                <?php if($job->customer->email): ?>
                                    <p class="text-sm text-gray-500">Email: <?php echo e($job->customer->email); ?></p>
                                <?php endif; ?>
                            </div>
                            
                            <div class="mb-4">
                                <h4 class="text-sm font-medium text-gray-500">Technician</h4>
                                <?php if($job->technician): ?>
                                    <p class="text-base"><?php echo e($job->technician->name); ?></p>
                                <?php else: ?>
                                    <p class="text-base text-gray-500">Not assigned</p>
                                    
                                    <!-- Assign Technician Form -->
                                    <form action="<?php echo e(route('jobs.assign-technician', $job)); ?>" method="POST" class="mt-2">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <div class="flex">
                                            <select name="technician_id" class="rounded-l-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50 text-sm">
                                                <option value="">Select Technician</option>
                                                <?php $__currentLoopData = $technicians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $technician): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($technician->id); ?>"><?php echo e($technician->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <button type="submit" class="bg-gray-800 text-white rounded-r-md px-3 py-0 text-sm">Assign</button>
                                        </div>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <!-- Device Info -->
                        <div>
                            <div class="mb-4">
                                <h4 class="text-sm font-medium text-gray-500">Device Information</h4>
                                <p class="text-base"><?php echo e($job->device_type); ?></p>
                                <?php if($job->brand || $job->model): ?>
                                    <p class="text-sm text-gray-600"><?php echo e($job->brand); ?> <?php echo e($job->model); ?></p>
                                <?php endif; ?>
                                <?php if($job->serial_number): ?>
                                    <p class="text-sm text-gray-600">S/N: <?php echo e($job->serial_number); ?></p>
                                <?php endif; ?>
                            </div>
                            
                            <div class="mb-4">
                                <h4 class="text-sm font-medium text-gray-500">Accessories</h4>
                                <p class="text-base"><?php echo e($job->accessories ?: 'None'); ?></p>
                            </div>
                            
                            <div class="mb-4">
                                <h4 class="text-sm font-medium text-gray-500">Cost Information</h4>
                                <p class="text-sm text-gray-600">Estimated: LKR <?php echo e(number_format($job->estimated_cost ?? 0, 2)); ?></p>
                                <p class="text-sm text-gray-600">Final: LKR <?php echo e(number_format($job->final_cost ?? 0, 2)); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Service Details -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                <div class="p-6 bg-white border-b border-gray-200">
                    <h3 class="text-lg font-medium text-gray-900 mb-4">Service Details</h3>
                    
                    <div class="mb-6">
                        <h4 class="text-sm font-medium text-gray-500 mb-2">Reported Issues</h4>
                        <div class="p-3 bg-gray-50 rounded-md text-gray-800">
                            <?php echo e($job->reported_issues); ?>

                        </div>
                    </div>
                    
                    <div class="mb-6">
                        <h4 class="text-sm font-medium text-gray-500 mb-2">Diagnosis</h4>
                        <div class="p-3 bg-gray-50 rounded-md text-gray-800">
                            <?php echo e($job->diagnosis ?: 'No diagnosis has been recorded yet.'); ?>

                        </div>
                    </div>
                    
                    <div class="mb-6">
                        <h4 class="text-sm font-medium text-gray-500 mb-2">Repair Notes</h4>
                        <div class="p-3 bg-gray-50 rounded-md text-gray-800">
                            <?php echo e($job->repair_notes ?: 'No repair notes have been recorded yet.'); ?>

                        </div>
                    </div>
                    
                    <div class="mb-6">
                        <h4 class="text-sm font-medium text-gray-500 mb-2">Parts Used</h4>
                        <div class="p-3 bg-gray-50 rounded-md text-gray-800">
                            <?php echo e($job->parts_used ?: 'No parts have been recorded.'); ?>

                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Job Notes -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <div class="flex justify-between items-center mb-4">
                        <h3 class="text-lg font-medium text-gray-900">Job Notes</h3>
                        <button type="button" id="addNoteBtn" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-md text-sm">Add Note</button>
                    </div>
                    
                    <!-- Add Note Form (hidden by default) -->
                    <div id="addNoteForm" class="mb-6 hidden">
                        <form action="<?php echo e(route('notes.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="service_job_id" value="<?php echo e($job->id); ?>">
                            
                            <div class="mb-4">
                                <label for="note" class="block text-sm font-medium text-gray-700">Note Content *</label>
                                <textarea name="note" id="note" rows="3" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"></textarea>
                            </div>
                            
                            <div class="mb-4">
                                <label class="inline-flex items-center">
                                    <input type="checkbox" name="is_private" value="1" class="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                                    <span class="ml-2 text-sm text-gray-600">Private note (only visible to staff)</span>
                                </label>
                            </div>
                            
                            <div class="flex justify-end">
                                <button type="button" id="cancelNoteBtn" class="text-gray-600 hover:text-gray-900 mr-2">Cancel</button>
                                <button type="submit" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-md text-sm">Save Note</button>
                            </div>
                        </form>
                    </div>
                    
                    <!-- Notes List -->
                    <div class="space-y-4">
                        <?php $__empty_1 = true; $__currentLoopData = $job->notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="p-4 bg-gray-50 rounded-md <?php echo e($note->is_private ? 'border-l-4 border-red-400' : ''); ?>">
                                <div class="flex justify-between items-start">
                                    <div>
                                        <p class="text-sm font-medium">
                                            <?php echo e($note->user->name); ?>

                                            <?php if($note->is_private): ?>
                                                <span class="text-xs text-red-500 ml-2">(Private)</span>
                                            <?php endif; ?>
                                        </p>
                                        <p class="text-xs text-gray-500"><?php echo e($note->created_at->format('M d, Y h:i A')); ?></p>
                                    </div>
                                    
                                    <div>
                                        <form action="<?php echo e(route('notes.destroy', $note)); ?>" method="POST" class="inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="text-red-600 hover:text-red-900 text-xs" onclick="return confirm('Are you sure you want to delete this note?')">Delete</button>
                                        </form>
                                    </div>
                                </div>
                                
                                <div class="mt-2 text-sm text-gray-800">
                                    <?php echo e($note->note); ?>

                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-gray-500 text-center py-4">No notes have been added yet.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Simple JavaScript to toggle the note form
        document.addEventListener('DOMContentLoaded', function() {
            const addNoteBtn = document.getElementById('addNoteBtn');
            const addNoteForm = document.getElementById('addNoteForm');
            const cancelNoteBtn = document.getElementById('cancelNoteBtn');
            
            addNoteBtn.addEventListener('click', function() {
                addNoteForm.classList.remove('hidden');
                addNoteBtn.classList.add('hidden');
            });
            
            cancelNoteBtn.addEventListener('click', function() {
                addNoteForm.classList.add('hidden');
                addNoteBtn.classList.remove('hidden');
            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?> <?php /**PATH C:\Users\Dhanushka\Desktop\laptop_service_job\resources\views/jobs/show.blade.php ENDPATH**/ ?>