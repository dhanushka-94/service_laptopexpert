<img src="{{ asset('logo.png') }}" alt="Laptop Service System Logo" {{ $attributes }} />
